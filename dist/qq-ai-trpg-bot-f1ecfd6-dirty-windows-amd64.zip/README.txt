# QQ AI TRPG Bot - 快速开始

## 系统要求
- Windows 10/11 (64位)
- 无需安装任何依赖，解压即用

## 快速开始

1. 解压压缩包到任意目录
2. 双击 `start.bat`（或右键用 PowerShell 运行 `start.ps1`）
3. 首次运行会自动创建 `.env` 配置文件并打开记事本
4. 在 `.env` 中填入你的 DeepSeek API Key：
   ```
   LLM_API_KEY=sk-your-key-here
   ```
5. 保存关闭记事本，再次双击 `start.bat` 启动
6. 浏览器打开 http://localhost:8080 即可使用

## 配置说明

### .env 文件（主要配置）
| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| LLM_API_KEY | DeepSeek API 密钥（必填） | - |
| LLM_MODEL | 模型名称 | deepseek-v4-flash |
| LLM_BASE_URL | API 地址 | https://api.deepseek.com |
| WEB_CHAT_TOKEN | 聊天页访问令牌（留空不校验） | - |
| ADMIN_TOKEN | 管理后台令牌（留空仅允许本机访问） | - |

### conf/trpc_go.yaml（服务端口等）
- Web 服务端口默认 8080，如需修改改 `server.service.port`
- 日志级别默认 debug

## 目录结构
```
qq-ai-trpg-bot/
  start.bat          # 一键启动（推荐）
  start.ps1          # PowerShell 启动脚本
  bot.exe            # 主程序
  .env.example       # 配置模板
  .env               # 你的配置（首次运行自动生成）
  conf/
    trpc_go.yaml     # 服务配置
  data/              # 运行时数据（自动创建）
  logs/              # 日志文件
```

## 获取 DeepSeek API Key
1. 访问 https://platform.deepseek.com/
2. 注册并创建 API Key
3. 粘贴到 .env 的 LLM_API_KEY=

## 常见问题

Q: 启动后无法访问 http://localhost:8080
A: 检查端口是否被占用，修改 conf/trpc_go.yaml 中的 port

Q: AI 不回复
A: 检查 .env 中 LLM_API_KEY 是否正确

Q: 如何重置数据
A: 删除 data/ 目录下的 .db 文件后重启