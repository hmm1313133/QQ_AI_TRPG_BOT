@echo off
chcp 65001 >nul 2>&1
title QQ AI TRPG Bot

echo ========================================
echo   QQ AI TRPG Bot
echo ========================================
echo.

REM 首次运行：从 .env.example 复制 .env
if not exist ".env" (
    echo [INFO] 首次运行，从 .env.example 创建 .env ...
    copy .env.example .env >nul
    echo [WARN] 请编辑 .env 填入 LLM_API_KEY 后重新运行
    echo.
    notepad .env
    exit /b 0
)

REM 加载 .env 环境变量
for /f "usebackq tokens=1,* delims==" %%a in (".env") do (
    set "line=%%a"
    if not "%%a"=="" if not "%%a:~0,1%"=="#" (
        set "%%a=%%b"
    )
)

echo [INFO] 正在启动...
echo [INFO] Web 界面: http://localhost:8080
echo [INFO] 按 Ctrl+C 停止
echo.

bot.exe
pause