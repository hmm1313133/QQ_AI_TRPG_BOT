$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
chcp 65001 | Out-Null

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  QQ AI TRPG Bot" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# 首次运行：从 .env.example 复制 .env
$envFile = Join-Path $PSScriptRoot ".env"
if (-not (Test-Path $envFile)) {
    Write-Host "[INFO] 首次运行，从 .env.example 创建 .env ..." -ForegroundColor Yellow
    Copy-Item ".env.example" ".env"
    Write-Host "[WARN] 请编辑 .env 填入 LLM_API_KEY 后重新运行" -ForegroundColor Red
    Write-Host "[INFO] 正在用记事本打开 .env ..." -ForegroundColor Yellow
    Start-Process notepad ".env" -Wait
    exit 0
}

# 加载 .env
Get-Content $envFile | ForEach-Object {
    $line = $_.Trim()
    if ($line -and -not $line.StartsWith("#")) {
        $parts = $line -split '=', 2
        if ($parts.Length -eq 2) {
            [System.Environment]::SetEnvironmentVariable($parts[0].Trim(), $parts[1].Trim(), "Process")
        }
    }
}

Write-Host ""
Write-Host "[INFO] 正在启动..." -ForegroundColor Yellow
Write-Host "[INFO] Web 界面: http://localhost:8080" -ForegroundColor Green
Write-Host "[INFO] 按 Ctrl+C 停止" -ForegroundColor Yellow
Write-Host ""

& "$PSScriptRoot\bot.exe"